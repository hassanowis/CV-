def handlecomboBoxChange(self):
    if self.filters_combo.currentIndex() == 0:
        self.label_3.setVisible(True)
        self.comboBox_2.setVisible(True)
        self.label_3.setText("Noise Type")
        self.comboBox_2.clear()
        new_options = ["Uniform", "Gaussian", "Salt & pepper"]
        self.comboBox_2.addItems(new_options)

    elif self.filters_combo.currentIndex() == 1:
        self.label_3.setVisible(True)
        self.comboBox_2.setVisible(True)
        self.label_3.setText("Filter Type")
        self.comboBox_2.clear()
        new_options = ["Average", "Gaussian", "Median"]
        self.comboBox_2.addItems(new_options)

    elif self.filters_combo.currentIndex() == 2:
        self.label_3.setVisible(True)
        self.comboBox_2.setVisible(True)
        self.label_3.setText("Detection Method")
        self.comboBox_2.clear()
        new_options = ["Sobel", "Roberts", "Prewitt", "Canny"]
        self.comboBox_2.addItems(new_options)

    elif self.filters_combo.currentIndex() == 3:
        self.label_3.setVisible(True)
        self.comboBox_2.setVisible(True)
        self.label_3.setText("Thresholding Method")
        self.comboBox_2.clear()
        new_options = ["Global", "Local"]
        self.comboBox_2.addItems(new_options)
    elif (
        self.filters_combo.currentIndex() == 5 or self.filters_combo.currentIndex() == 4
    ):
        self.label_4.setVisible(False)
        self.label_3.setVisible(False)
        self.comboBox_2.setVisible(False)
        self.lineEdit.setVisible(False)
        self.label_5.setVisible(False)
        self.lineEdit_2.setVisible(False)
    elif (
        self.filters_combo.currentIndex() == 6 or self.filters_combo.currentIndex() == 7
    ):
        self.label_3.setVisible(False)
        self.comboBox_2.setVisible(False)
        self.label_13.setVisible(False)
        self.label_21.setVisible(False)
        self.label_22.setVisible(False)
        self.label_23.setVisible(False)
        self.horizontalSlider.setVisible(False)
        self.horizontalSlider_2.setVisible(False)
        self.horizontalSlider_3.setVisible(False)
        self.horizontalSlider_4.setVisible(False)
        self.label_37.setVisible(False)
        self.label_38.setVisible(False)
        self.label_39.setVisible(False)
        self.label_40.setVisible(False)
        self.label_4.setVisible(True)
        self.label_4.setText("Cutoff frequency")
        self.lineEdit.setVisible(True)
    else:
        self.label_3.setVisible(False)
        self.comboBox_2.setVisible(False)
        self.label_13.setVisible(False)
        self.label_21.setVisible(False)
        self.label_22.setVisible(False)
        self.label_23.setVisible(False)
        self.horizontalSlider.setVisible(False)
        self.horizontalSlider_2.setVisible(False)
        self.horizontalSlider_3.setVisible(False)
        self.horizontalSlider_4.setVisible(False)
        self.label_37.setVisible(False)
        self.label_38.setVisible(False)
        self.label_39.setVisible(False)
        self.label_40.setVisible(False)


def handlecomboBoxChange2(self):
    if self.filters_combo.currentIndex() == 0:
        self.label_13.setVisible(False)
        self.label_21.setVisible(False)
        self.label_22.setVisible(False)
        self.label_23.setVisible(False)
        self.horizontalSlider.setVisible(False)
        self.horizontalSlider_2.setVisible(False)
        self.horizontalSlider_3.setVisible(False)
        self.horizontalSlider_4.setVisible(False)
        self.label_37.setVisible(False)
        self.label_38.setVisible(False)
        self.label_39.setVisible(False)
        self.label_40.setVisible(False)
        self.comboBox.setVisible(False)
        self.label_12.setVisible(False)
        if self.comboBox_2.currentIndex() == 0:
            self.label_4.setText("Noise Value")
            self.label_5.setVisible(False)
            self.label_6.setVisible(False)
            self.lineEdit_2.setVisible(False)
            self.lineEdit_3.setVisible(False)
        elif self.comboBox_2.currentIndex() == 1:
            self.label_5.setVisible(True)
            self.lineEdit_2.setVisible(True)
            self.label_4.setText("Mean")
            self.label_5.setText("Sigma")
            self.label_6.setVisible(False)
            self.lineEdit_3.setVisible(False)
        else:
            self.label_5.setVisible(True)
            self.lineEdit_2.setVisible(True)
            self.label_4.setText("W pixels")
            self.label_5.setText("B pixels")
            self.label_6.setVisible(False)
            self.lineEdit_3.setVisible(False)
    elif self.filters_combo.currentIndex() == 1:
        self.label_13.setVisible(False)
        self.label_21.setVisible(False)
        self.label_22.setVisible(False)
        self.label_23.setVisible(False)
        self.horizontalSlider.setVisible(False)
        self.horizontalSlider_2.setVisible(False)
        self.horizontalSlider_3.setVisible(False)
        self.horizontalSlider_4.setVisible(False)
        self.label_37.setVisible(False)
        self.label_38.setVisible(False)
        self.label_39.setVisible(False)
        self.label_40.setVisible(False)
        self.comboBox.setVisible(False)
        self.label_12.setVisible(False)
        if self.comboBox_2.currentIndex() == 0:
            self.label_4.setVisible(True)
            self.lineEdit.setVisible(True)
            self.label_4.setText("Kernel size")
            self.label_5.setVisible(False)
            self.label_6.setVisible(False)
            self.lineEdit_2.setVisible(False)
            self.lineEdit_3.setVisible(False)
        elif self.comboBox_2.currentIndex() == 1:
            self.label_4.setVisible(True)
            self.lineEdit.setVisible(True)
            self.label_4.setText("Sigma")
            self.label_5.setVisible(False)
            self.label_6.setVisible(False)
            self.lineEdit_2.setVisible(False)
            self.lineEdit_3.setVisible(False)
        else:
            self.label_4.setVisible(False)
            self.label_5.setVisible(False)
            self.label_6.setVisible(False)
            self.lineEdit.setVisible(False)
            self.lineEdit_2.setVisible(False)
            self.lineEdit_3.setVisible(False)
    elif self.filters_combo.currentIndex() == 2:
        self.label_13.setVisible(False)
        self.label_21.setVisible(False)
        self.label_22.setVisible(False)
        self.label_23.setVisible(False)
        self.horizontalSlider.setVisible(False)
        self.horizontalSlider_2.setVisible(False)
        self.horizontalSlider_3.setVisible(False)
        self.horizontalSlider_4.setVisible(False)
        self.label_37.setVisible(False)
        self.label_38.setVisible(False)
        self.label_39.setVisible(False)
        self.label_40.setVisible(False)
        self.label_12.setText("Detection type")
        if self.comboBox_2.currentIndex() != 3:
            self.comboBox.clear()
            new_options = ["Horizontal", "Vertical", "Both"]
            self.comboBox.addItems(new_options)
            self.label_4.setVisible(False)
            self.label_5.setVisible(False)
            self.label_6.setVisible(False)
            self.lineEdit.setVisible(False)
            self.lineEdit_2.setVisible(False)
            self.lineEdit_3.setVisible(False)
            self.comboBox.setVisible(True)
            self.label_12.setVisible(True)

        elif self.comboBox_2.currentIndex() == 3:

            self.label_4.setVisible(True)
            self.lineEdit.setVisible(True)
            self.lineEdit_2.setVisible(True)
            self.comboBox.setVisible(False)
            self.label_5.setVisible(True)
            self.label_12.setVisible(False)
            self.label_5.setText("High threshold")
            self.label_4.setText("Low threshold")

    elif self.filters_combo.currentIndex() == 3:
        if self.comboBox_2.currentIndex() == 0:
            self.label_13.setVisible(True)
            self.horizontalSlider.setVisible(True)
            self.label_13.setVisible(True)
            self.label_21.setVisible(False)
            self.label_22.setVisible(False)
            self.label_23.setVisible(False)
            self.horizontalSlider.setVisible(True)
            self.horizontalSlider_2.setVisible(False)
            self.horizontalSlider_3.setVisible(False)
            self.horizontalSlider_4.setVisible(False)
            self.label_37.setVisible(True)
            self.label_38.setVisible(False)
            self.label_39.setVisible(False)
            self.label_40.setVisible(False)
        else:
            self.label_4.setVisible(False)
            self.label_5.setVisible(False)
            self.label_6.setVisible(False)
            self.lineEdit.setVisible(False)
            self.lineEdit_2.setVisible(False)
            self.lineEdit_3.setVisible(False)
            self.label_13.setVisible(True)
            self.label_21.setVisible(True)
            self.label_22.setVisible(True)
            self.label_23.setVisible(True)
            self.horizontalSlider.setVisible(True)
            self.horizontalSlider_2.setVisible(True)
            self.horizontalSlider_3.setVisible(True)
            self.horizontalSlider_4.setVisible(True)
            self.label_37.setVisible(True)
            self.label_38.setVisible(True)
            self.label_39.setVisible(True)
            self.label_40.setVisible(True)
            self.comboBox.setVisible(False)
            self.label_12.setVisible(False)
    elif (
        self.filters_combo.currentIndex() == 5 or self.filters_combo.currentIndex() == 4
    ):
        self.label_4.setVisible(False)
        self.label_3.setVisible(False)
        self.comboBox_2.setVisible(False)
        self.lineEdit.setVisible(False)
        self.label_5.setVisible(False)
        self.lineEdit_2.setVisible(False)


def handelcomboxchanges3(self):
    if self.types.currentIndex() == 0:
        self.kernalsizelabel.setVisible(True)
        self.kernalsize.setVisible(True)
        self.label_14.setVisible(False)
        self.horizontalSlider_5.setVisible(False)
        self.label_32.setVisible(False)
        self.label_24.setVisible(False)
        self.horizontalSlider_6.setVisible(False)
        self.label_33.setVisible(False)

        self.label_25.setVisible(False)
        self.horizontalSlider_7.setVisible(False)
        self.label_34.setVisible(False)
        self.horizontalSlider_8.setVisible(False)
        self.label_35.setVisible(False)

    elif self.types.currentIndex() == 1:
        self.kernalsizelabel.setVisible(False)
        self.kernalsize.setVisible(False)
        self.label_14.setVisible(True)
        self.horizontalSlider_5.setVisible(True)
        self.label_24.setVisible(True)
        self.horizontalSlider_6.setVisible(True)
        self.label_25.setVisible(True)
        self.horizontalSlider_7.setVisible(True)
        self.label_26.setVisible(False)
        self.horizontalSlider_8.setVisible(False)
        self.label_32.setVisible(True)
        self.label_33.setVisible(True)
        self.label_34.setVisible(True)
        self.label_35.setVisible(False)

    elif self.types.currentIndex() == 2:
        self.kernalsizelabel.setVisible(False)
        self.kernalsize.setVisible(False)
        self.horizontalSlider_5.setVisible(True)
        self.label_14.setVisible(True)
        self.label_14.setText("Thickness")
        self.horizontalSlider_6.setVisible(False)
        self.label_25.setVisible(False)
        self.horizontalSlider_7.setVisible(False)
        self.label_26.setVisible(False)
        self.horizontalSlider_8.setVisible(False)
        self.label_24.setVisible(False)
        self.label_32.setVisible(True)
        self.label_33.setVisible(False)
        self.label_34.setVisible(False)
        self.label_35.setVisible(False)

    elif self.types.currentIndex() == 3:
        self.kernalsizelabel.setVisible(False)
        self.kernalsize.setVisible(False)
        self.label_14.setVisible(True)
        self.label_14.setText("minimum radius")
        self.horizontalSlider_5.setVisible(True)

        self.label_24.setVisible(True)
        self.horizontalSlider_6.setVisible(True)
        self.label_24.setText(" maximum radius")

        self.label_25.setVisible(False)
        self.horizontalSlider_7.setVisible(False)

        self.label_26.setVisible(False)
        self.horizontalSlider_8.setVisible(False)

        self.label_32.setVisible(True)
        self.label_33.setVisible(True)
        self.label_34.setVisible(False)
        self.label_35.setVisible(False)


def handelcomboxchanges4(self):
    if self.comboBox_5.currentIndex() == 0:
        self.label_64.setVisible(True)
        self.horizontalSlider_15.setVisible(True)
        self.label_65.setVisible(True)
        self.horizontalSlider_16.setVisible(True)
        self.label_73.setVisible(True)
        self.label_74.setVisible(True)
    elif self.comboBox_5.currentIndex() == 1:
        self.label_64.setVisible(False)
        self.horizontalSlider_15.setVisible(False)
        self.label_73.setVisible(False)
        self.label_65.setVisible(False)
        self.horizontalSlider_16.setVisible(False)
        self.label_74.setVisible(False)
    elif self.comboBox_5.currentIndex() == 2:
        self.label_64.setVisible(True)
        self.label_65.setText(" Y")
        self.label_64.setText(" X")

        self.horizontalSlider_15.setVisible(True)
        self.label_73.setVisible(True)
        self.label_65.setVisible(True)
        self.horizontalSlider_16.setVisible(True)
        self.label_74.setVisible(True)
    elif self.comboBox_5.currentIndex() == 3:
        self.label_64.setVisible(True)
        self.label_64.setText("number of clusters ")
        self.horizontalSlider_15.setVisible(True)
        self.label_73.setVisible(True)
        self.label_65.setVisible(True)
        self.label_65.setText("initial_clusters_number ")

        self.horizontalSlider_16.setVisible(True)
        self.label_74.setVisible(True)

def handelcomboxchanges5(self):
    if self.comboBox_6.currentIndex() == 0:
        self.comboBox_7.setVisible(True)

       

    elif self.comboBox_6.currentIndex() == 1:
        self.comboBox_7.setVisible(True)
        
    elif self.comboBox_6.currentIndex() == 2:
        self.comboBox_7.setVisible(True)
        
   