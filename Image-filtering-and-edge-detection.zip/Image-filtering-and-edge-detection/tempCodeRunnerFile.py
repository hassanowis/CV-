        self.label_67.setText(f"Distance: {distance}, Name: {recognized_image_name}")     
