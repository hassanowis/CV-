import cv2

import cv2

def detect_faces(image):
    # Load the pre-trained face detection model
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_alt2.xml')

    # Check if the image is not grayscale
    if len(image.shape) > 2 and image.shape[2] > 1:
        # Convert the image to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    else:
        # If the image is already grayscale, just use it as is
        gray = image

    # Detect faces in the image
    faces = face_cascade.detectMultiScale(gray, 1.1, 4)

    # Draw rectangles around the detected faces
    for (x, y, w, h) in faces:
        cv2.rectangle(image, (x, y), (x+w, y+h), (0, 255, 0), 2)

    # Return the image with the detected faces
    return image


import cv2
import numpy as np
import os
import os
import matplotlib.pyplot as plt




# Step 1: Reshape images to 1D vectors
def reshape_images(images):
    return images.reshape(images.shape[0], -1).T

# Step 2: Construct data matrix
def construct_data_matrix(images):
    return reshape_images(images)

# Step 3: Get the Mean Image
def get_mean_image(data_matrix):
    num_images = data_matrix.shape[1]
    mean_image = np.sum(data_matrix, axis=1, keepdims=True) / num_images
    return mean_image

# Step 4: Subtract the mean image from all images
def subtract_mean_image(data_matrix, mean_image):
    return data_matrix - mean_image

# Step 5: Get the Covariance matrix
def get_covariance_matrix(subtracted_data):
    num_images = subtracted_data.shape[1]
    covariance_matrix = np.dot(subtracted_data, subtracted_data.T) / (num_images - 1 )
    return covariance_matrix

def get_eigen_values_and_vectors(covariance_matrix):
    """
    Calculates eigenvalues and eigenvectors.

    Parameters:
    covariance_matrix (numpy array): Covariance matrix.

    Returns:
    numpy array: Eigenvalues.
    numpy array: Eigenvectors.
    """
    eigen_values, eigen_vectors = np.linalg.eig(covariance_matrix)
    return eigen_values, eigen_vectors

# Step 6: Normalize the eigen vectors
def normalize_eigen_vectors(eigen_values, eigen_vectors, threshold=0.9):
    total_var = np.sum(eigen_values)
    var_sum = 0
    sorted_indices = np.argsort(eigen_values)[::-1]
    for i, idx in enumerate(sorted_indices):
        var_sum += eigen_values[idx]
        if var_sum / total_var >= threshold:
            return eigen_vectors[:, sorted_indices[:i + 1]]

# Step 7: Keep only the significant eigen vectors
def keep_significant_eigen_vectors(eigen_values, eigen_vectors, threshold=0.9):
    normalized_eigen_vectors = normalize_eigen_vectors(eigen_values, eigen_vectors, threshold)
    return normalized_eigen_vectors

# Step 8: Map all images to new components
def map_to_new_components(data_matrix, eigen_vectors):
    return np.dot(eigen_vectors.T, data_matrix)

# Step 9: Face Recognition
def recognize_face(image, mean_image, eigen_vectors, projected_data, threshold):
    image = image.reshape(-1, 1)
    mean_image = mean_image.reshape(-1, 1)  # Ensure mean image has the same shape as the test image
    subtracted_image = image - mean_image
    projected_image = np.dot(eigen_vectors.T, subtracted_image)
    distances = np.linalg.norm(projected_data - projected_image, axis=0)
    recognized_index = np.argmin(distances)
    min_distance = np.min(distances)
    if min_distance > threshold:
        return None, min_distance
    return recognized_index, min_distance

# Function to load images from a directory
def load_images_from_folder(folder):
    images = []
    for filename in os.listdir(folder):
        img = cv2.imread(os.path.join(folder, filename), cv2.IMREAD_GRAYSCALE)
        if img is not None:
            images.append(img)
    return np.array(images)

# Function to perform face recognition
def perform_face_recognition(images_folder, test_image, threshold=4200):
    # Load images
    images = load_images_from_folder(images_folder)
    
    if len(images) == 0:
        return None, None, None, None, "No images in the dataset"
    
    # Construct data matrix
    data_matrix = construct_data_matrix(images)
    
    # Get mean image
    mean_image = get_mean_image(data_matrix)
    
    # Subtract the mean image from all images
    subtracted_data = subtract_mean_image(data_matrix, mean_image)
    
    # Get the covariance matrix
    covariance_matrix = get_covariance_matrix(subtracted_data)
    
    # Check if eigenvalues and eigenvectors are saved
    if os.path.exists('eigen.npz'):
        eigen = np.load('eigen.npz')
        eigen_values = eigen['eigen_values']
        eigen_vectors = eigen['eigen_vectors']
    else:
        # Get eigen values and eigen vectors
        eigen_values, eigen_vectors = np.linalg.eig(covariance_matrix)
        # Save eigen values and eigen vectors
        np.savez('eigen.npz', eigen_values=eigen_values, eigen_vectors=eigen_vectors)
    
    # Keep only the significant eigen vectors
    eigen_vectors = keep_significant_eigen_vectors(eigen_values, eigen_vectors)
    
    # Map all images to new components
    projected_data = map_to_new_components(subtracted_data, eigen_vectors)

    # Recognize face
    recognized_index, distance = recognize_face(test_image, mean_image, eigen_vectors, projected_data, threshold)

    # Check if recognized_index is not None
    if recognized_index is not None:
        # Get the name of the recognized image
        recognized_image_name = os.listdir(images_folder)[recognized_index]
        
        # Load recognized image
        recognized_image = images[recognized_index]
    else:
        recognized_image_name = None
        recognized_image = None

    # Return recognized index, distance, test image, and recognized image name
    return recognized_index, distance, test_image, recognized_image, recognized_image_name




# def ROC_curve(recognized_index, distance, test_image, recognized_image, recognized_image_name):
#     # Calculate the threshold
#     threshold = 0.01 * distance

#     # Calculate the true positive rate (TPR) and false positive rate (FPR)
#     tpr = np.sum(recognized_index == recognized_index) / len(recognized_index)
#     fpr = np.sum(distance < threshold) / len(distance)

#     # Return the TPR and FPR
#     return tpr, fpr
# #draw roc curve
# def draw_roc_curve(tpr, fpr):
#     plt.figure()
#     plt.plot(fpr, tpr, color='darkorange', lw=2)
#     plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
#     plt.xlim([0.0, 1.0])
#     plt.ylim([0.0, 1.05])
#     plt.xlabel('False Positive Rate')
#     plt.ylabel('True Positive Rate')
#     plt.title('Receiver Operating Characteristic (ROC) Curve')
#     plt.show()


def perform_pca(self):
        """
        Method to perform PCA on the images.
        """
        true_positive = 0
        false_positive = 0
        true_negative = 0
        false_negative = 0
        false_positive_rate = []
        true_positive_rate = []
        test_folder = load_images_from_folder()
        threshold = self.recog_slider_2.value()
        epsilon = 1e-10
        for i in range(len(self.testing_image_paths)):
            recognized_image_name = perform_face_recognition(test_folder, threshold, self.eigen_vectors,
                                       self.training_projected_data, self.training_labels, self.mean_image_training)
            self.predicted_labels.append(self.testing_labels[i])
            if self.training_labels[recognized_image_name] == self.testing_labels[i] and recognized_image_name != -1:
                true_positive += 1
            elif self.training_labels[recognized_image_name] != self.testing_labels[i] and recognized_image_name != -1:
                false_positive += 1
            elif recognized_image_name == -1 and self.testing_labels[i] in self.training_labels:
                false_negative += 1
            else:
                true_negative += 1

            false_positive_rate.append(false_positive / (false_positive + true_negative + epsilon))
            true_positive_rate.append(true_positive / (true_positive + false_negative + epsilon))

        print("True Positive : ", true_positive)
        print("False Positive : ", false_positive)
        print("True Negative : ", true_negative)
        print("False Negative : ", false_negative)
        print("True Positive Rate : ", true_positive_rate)
        print("False Positive Rate : ", false_positive_rate)
        print("len(true_positive_rate) : ", len(true_positive_rate))
        print("len(false_positive_rate) : ", len(false_positive_rate))
        accuracy = (true_positive + true_negative) / (true_positive + true_negative + false_positive + false_negative)
        precision = true_positive / (true_positive + false_positive)
        recall = true_positive / (true_positive + false_negative)
        if true_negative + false_positive == 0:
            specificity = 0
            false_positive_rate_value = 0
        else:
            specificity = true_negative / (true_negative + false_positive)
            false_positive_rate_value = false_positive / (false_positive + true_negative)
        f1_score = 2 * (precision * recall) / (precision + recall)

        self.accuracy_lbl.setText("Accuracy : " + str(accuracy))
        self.precision_lbl.setText("Precision : " + str(precision))
        self.recall_lbl.setText("Recall : " + str(recall))
        self.specificity_lbl.setText("Specificity : " + str(specificity))
        self.false_positive_rate_lbl.setText("False Positive Rate : " + str(false_positive_rate_value))
        self.f1_score_lbl.setText("F1 Score : " + str(f1_score))

        # ROC Curve and AUC Score
        auc_value = self.calculate_auc(false_positive_rate, true_positive_rate)
        self.plot_roc(false_positive_rate, true_positive_rate, auc_value)